import swaggerJsdoc from 'swagger-jsdoc';
import config from '../config/env.js';

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'EcoRueda API',
      version: '1.0.0',
      description: 'API REST para la plataforma de movilidad sostenible EcoRueda.\n\nAutenticación: usar esquema Bearer JWT. Enviar encabezado Authorization: Bearer <token>.\nExpiración por defecto del token: ' + (process.env.JWT_EXPIRE || '24h') + '. Issuer: ' + (process.env.JWT_ISSUER || 'ecorueda-api') + ', Audience: ' + (process.env.JWT_AUDIENCE || 'ecorueda-client') + '.\nAl expirar el token devolverá 401 con mensaje "Token expirado". Renueve iniciando sesión nuevamente.',
      contact: {
        name: 'Dylan',
        email: 'dylan@ecorueda.com'
      }
    },
    servers: [
      {
        url: `http://localhost:${config.PORT}${config.API_PREFIX}`,
        description: 'Servidor de desarrollo'
      },
      {
        url: `https://ecorueda-api.azurewebsites.net${config.API_PREFIX}`,
        description: 'Servidor de producción'
      }
    ],
    security: [
      { BearerAuth: [] }
    ],
    components: {
      securitySchemes: {
        BearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT'
        }
      },
      schemas: {
        AuthLoginResponse: {
          type: 'object',
          properties: {
            user: { $ref: '#/components/schemas/User' },
            token: { type: 'string', description: 'JWT firmado (Bearer). Expira en ' + (process.env.JWT_EXPIRE || '24h') },
          }
        },
        User: {
          type: 'object',
          properties: {
            id: { type: 'string', format: 'uuid' },
            name: { type: 'string' },
            email: { type: 'string', format: 'email' },
            phone: { type: 'string' },
            balance: { type: 'number', format: 'float' },
            createdAt: { type: 'string', format: 'date-time' }
          }
        },
        Vehicle: {
          type: 'object',
          properties: {
            id: { type: 'string', format: 'uuid' },
            company: { type: 'string', enum: ['tier', 'lime', 'bird'] },
            type: { type: 'string', enum: ['scooter', 'bike'] },
            lat: { type: 'number', format: 'float' },
            lng: { type: 'number', format: 'float' },
            battery: { type: 'integer', minimum: 0, maximum: 100 },
            pricePerMin: { type: 'number', format: 'float' },
            reserved: { type: 'boolean' },
            status: { type: 'string', enum: ['available', 'in_use', 'maintenance'] }
          }
        },
        Trip: {
          type: 'object',
          properties: {
            id: { type: 'string', format: 'uuid' },
            userId: { type: 'string', format: 'uuid' },
            vehicleId: { type: 'string', format: 'uuid' },
            type: { type: 'string' },
            duration: { type: 'integer' },
            distance: { type: 'number', format: 'float' },
            price: { type: 'number', format: 'float' },
            status: { type: 'string', enum: ['ongoing', 'completed', 'cancelled'] },
            startTime: { type: 'string', format: 'date-time' },
            endTime: { type: 'string', format: 'date-time' }
          }
        },
        Error: {
          type: 'object',
          properties: {
            success: { type: 'boolean' },
            message: { type: 'string' },
            error: { type: 'string' }
          }
        }
      }
    }
  },
  apis: ['./src/routes/*.js']
};

export const swaggerSpec = swaggerJsdoc(options);

export default swaggerSpec;
