import express from 'express';
import { VehicleController } from '../controllers/index.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

/**
 * @swagger
 * /vehicles:
 *   get:
 *     summary: Listar vehículos disponibles
 *     tags:
 *       - Vehículos
 *     security:
 *       - BearerAuth: []
 *     responses:
 *       200:
 *         description: Lista de vehículos disponibles
 */
router.get('/', authenticate, VehicleController.getAvailable.bind(VehicleController));

/**
 * @swagger
 * /vehicles/search:
 *   get:
 *     summary: Buscar vehículos cercanos
 *     tags:
 *       - Vehículos
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: query
 *         name: lat
 *         required: true
 *         schema:
 *           type: number
 *       - in: query
 *         name: lng
 *         required: true
 *         schema:
 *           type: number
 *       - in: query
 *         name: radius
 *         schema:
 *           type: number
 *           default: 1
 *       - in: query
 *         name: type
 *         schema:
 *           type: string
 *           enum: [scooter, bike]
 *       - in: query
 *         name: company
 *         schema:
 *           type: string
 *           enum: [tier, lime, bird]
 *     responses:
 *       200:
 *         description: Vehículos encontrados
 */
router.get('/search', authenticate, VehicleController.search.bind(VehicleController));

/**
 * @swagger
 * /vehicles/location/{canton}/{distrito}:
 *   get:
 *     summary: Buscar vehículos por ubicación
 *     tags:
 *       - Vehículos
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: canton
 *         required: true
 *         schema:
 *           type: string
 *       - in: path
 *         name: distrito
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Vehículos en la ubicación
 */
router.get('/location/:canton/:distrito', authenticate, VehicleController.searchByLocation.bind(VehicleController));

/**
 * @swagger
 * /vehicles/stats:
 *   get:
 *     summary: Obtener estadísticas de disponibilidad
 *     tags:
 *       - Vehículos
 *     security:
 *       - BearerAuth: []
 *     responses:
 *       200:
 *         description: Estadísticas de vehículos
 */
router.get('/stats', authenticate, VehicleController.getStats.bind(VehicleController));

/**
 * @swagger
 * /vehicles/{id}:
 *   get:
 *     summary: Obtener detalle de vehículo
 *     tags:
 *       - Vehículos
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Detalle del vehículo
 *       404:
 *         description: Vehículo no encontrado
 */
router.get('/:id', authenticate, VehicleController.getVehicle.bind(VehicleController));

/**
 * @swagger
 * /vehicles/{id}/reserve:
 *   post:
 *     summary: Reservar vehículo
 *     tags:
 *       - Vehículos
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Vehículo reservado
 */
router.post('/:id/reserve', authenticate, VehicleController.reserve.bind(VehicleController));

/**
 * @swagger
 * /vehicles/{id}/release:
 *   post:
 *     summary: Liberar vehículo
 *     tags:
 *       - Vehículos
 *     security:
 *       - BearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               battery:
 *                 type: integer
 *               lat:
 *                 type: number
 *               lng:
 *                 type: number
 *             required:
 *               - battery
 *               - lat
 *               - lng
 *     responses:
 *       200:
 *         description: Vehículo liberado
 */
router.post('/:id/release', authenticate, VehicleController.release.bind(VehicleController));

export default router;
